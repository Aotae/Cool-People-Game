﻿using UnityEngine;
using System.Collections;

public class ScrollBG : MonoBehaviour{

	public float scrollSpeed;
	public GameObject Background;
	Renderer Parallax;
	private Vector2 savedOffset;
	private Vector2 pausedOffset;
	private PopUp Check;

	void Awake(){
		Parallax=Background.GetComponent<Renderer>();
		savedOffset = Parallax.sharedMaterial.GetTextureOffset("_MainTex");
		Check=PopUp.Instance();
	}

	void Update(){
		if (Check.modalpanelObject.activeSelf!=true){
			float x = Mathf.Repeat(Time.time * scrollSpeed, 1);
			Vector2 offset = new Vector2(x, savedOffset.y);
			Parallax.sharedMaterial.SetTextureOffset("_MainTex", offset);
			pausedOffset = offset;
			if (Check.modalpanelObject == true){
				Parallax.sharedMaterial.SetTextureOffset("_MainTex", pausedOffset);
			}
		}
	}
	void OnDisable(){
		Parallax.sharedMaterial.SetTextureOffset("_MainTex", savedOffset);
	}
}