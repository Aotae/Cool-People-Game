﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class PopUp : MonoBehaviour {
	public Text question;
	public Image Icon;
	public Button Yes;
	public Button No;
	public GameObject modalpanelObject;

	//Check for PopUp//
	private static PopUp ModalPanel;
	public static PopUp Instance()
	{
		if (!ModalPanel)
		{
			ModalPanel = FindObjectOfType(typeof(PopUp)) as PopUp;
			if (!ModalPanel)
				Debug.LogError("There needs to be one active PopUp script on a GameObject in your scene.");
		}

		return ModalPanel;
	}

	void Awake(){
		modalpanelObject.SetActive(false);
	}
	public void Choice(string question, UnityAction YesEvent, UnityAction NoEvent){
		modalpanelObject.SetActive(true);

		Yes.onClick.RemoveAllListeners();
		Yes.onClick.AddListener(YesEvent);
		Yes.onClick.AddListener(ClosePanel);

		No.onClick.RemoveAllListeners();
		No.onClick.AddListener(NoEvent);
		No.onClick.AddListener(ClosePanel);

		this.question.text = question;

		this.Icon.gameObject.SetActive(false);
		Yes.gameObject.SetActive(true);
		No.gameObject.SetActive(true);

	}

	public void Choice(string question, Sprite Icon, UnityAction YesEvent, UnityAction NoEvent)
	{
		modalpanelObject.SetActive(true);

		Yes.onClick.RemoveAllListeners();
		Yes.onClick.AddListener(YesEvent);
		Yes.onClick.AddListener(ClosePanel);

		No.onClick.RemoveAllListeners();
		No.onClick.AddListener(NoEvent);
		No.onClick.AddListener(ClosePanel);

		this.question.text = question;
		this.Icon.sprite = Icon;
		this.Icon.gameObject.SetActive(true);
		Yes.gameObject.SetActive(true);
		No.gameObject.SetActive(true);

	}
	void ClosePanel(){
		Yes.onClick.RemoveAllListeners();
		No.onClick.RemoveAllListeners();
		modalpanelObject.SetActive(false);
	}

}
