﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine;
public class Test : MonoBehaviour {
	public Sprite IconImage;
	private PopUp modalpanel;
	private DisplayManager display;
	private string affirmation;
	private string negativefeed;
	public Text question;
	public Text Yes;
	public Text No;
	void Awake(){
		modalpanel = PopUp.Instance();
		display = DisplayManager.Instance();
	}
	public void TestYN(){
		affirmation = "SURVIVOR GET!";
		negativefeed = "Greg will remember this.";
		Yes.text = "SEND HELP.";
		No.text = "NOT OUR PROBLEM.";
		question.text = "(Insert Character NAME HERE), has spotted an oupost! There might be Survivors who need help! Quickly send some one to search! ";
		modalpanel.Choice(question.text,TestYesFunction, TestNoFunction);
	}
	public void TestYN2(){
		affirmation = "Yeet!";
		negativefeed = "Then why you tryin to take it foo?";
		Yes.text = "Yes";
		No.text = "No";
		question.text = "Is this your car?";
		modalpanel.Choice(question.text,IconImage, TestYesFunction, TestNoFunction);
	}
	void TestYesFunction (){
		display.DisplayMessage(affirmation);
	}
	void TestNoFunction (){
		display.DisplayMessage(negativefeed);
	}

}
