﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SizeSet : MonoBehaviour {
	public Canvas UiOverlay;
	public GameObject UiPanel;
	RectTransform Transformer;
	RectTransform Transformee;
	[Range(-4, 4)] public float Size = 1;
	void Awake(){
		Transformee = UiPanel.GetComponent<RectTransform>();
		Transformer = UiOverlay.GetComponent<RectTransform>();
		Vector2 Transfer = Transformer.sizeDelta;
		Transformee.sizeDelta = new Vector2(Transfer.x, Transfer.y /Size);
		Debug.Log(Transformer.sizeDelta);
		Debug.Log(Transformee.sizeDelta);
	}
}
