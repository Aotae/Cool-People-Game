﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class Scroll : MonoBehaviour {
	
	//Gas Gauge animation//
	public GameObject Panel;
	public Image GasGauge;
	[Range(0, 40)] public int Gas = 20;
	Image[] Fuel;
	void Awake(){
		Fuel = new Image[Gas];
		for (int ii = 0; ii < Fuel.Length; ii++){
			Image Gallons = Instantiate(GasGauge);
			Gallons.transform.SetParent(Panel.transform, false);
		}
	}
}

